// Creating variables
var socket = io();

function update() {
    
}

function draw() {
    
}

function keyup(key) {
	
}
function mouseup() {
    
}
